package com.example.Neha.hangman;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class AddWords extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_words);

        final DatabaseHelper db = new DatabaseHelper(this);
        String[] categories = db.getCategories();
        final Spinner spinner = (Spinner) findViewById(R.id.spinner2);

        ArrayAdapter<CharSequence> adapter = new ArrayAdapter<CharSequence>(this, android.R.layout.simple_spinner_item, new ArrayList<CharSequence>());
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        for (String s : categories) adapter.add(s);

        final EditText word = (EditText) findViewById(R.id.editText3);
        final EditText hint = (EditText) findViewById(R.id.editText4);
        final Button add = (Button) findViewById(R.id.button6);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (word.getText().toString() == "")
                    Toast.makeText(getApplicationContext(), "You need to have a word!",Toast.LENGTH_SHORT).show();
                else if (hint.getText().toString() == "")
                    Toast.makeText(getApplicationContext(), "You need to have a hint!", Toast.LENGTH_SHORT).show();
                else {
                    db.addWord(spinner.getSelectedItem().toString().toUpperCase(), word.getText().toString(), hint.getText().toString());
                    Toast.makeText(getApplicationContext(), "Success!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
