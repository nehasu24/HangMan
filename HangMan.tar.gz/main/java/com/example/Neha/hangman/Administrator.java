package com.example.Neha.hangman;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class Administrator extends AppCompatActivity {

    private static String USER_NUMBER; //Number of the User
    private static Administrator inst;
    private AdministratorModel hangman;
    private static DatabaseHelper db;
    private SmsProtocol protocol;
    private TextView outcome;
    private PreferencesHelper prefdb;

    //Received via message, must be stored here. Only once, so it's ok.
    private String category;

    //For the messaging system
    public static Administrator instance() {
        return inst;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        inst = this;
        category = "N.A";
        setContentView(R.layout.activity_administrator);
        protocol = new SmsProtocol();
        db = new DatabaseHelper(this);
        prefdb = new PreferencesHelper(this);


        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            USER_NUMBER = extras.getString("USER_NUMBER");
        }

        prefdb.insertContact(USER_NUMBER);

        outcome = (TextView) findViewById(R.id.textView19);
        outcome.setVisibility(View.INVISIBLE);
        //Need to get the database
        //Wait for message
        //Pick a word
    }

    //Used by messaging system
    private void sendCategory(String category) {
        this.category = category;
        refresh();
    }

    private void refresh() {
        TextView cat = (TextView) findViewById(R.id.textView5);
        cat.setText(category);
        category = category.toUpperCase();
        Log.d("admin", "the category is " + category);
        String word = db.getRandomWord(category);
        String hint = db.getHint(word);
        Log.d("admin", "the word we pick is " + word);
        hangman = new AdministratorModel(word);
        hangman.setHint(hint);
        TextView wrd = (TextView) findViewById(R.id.textView7);
        wrd.setText(word);
        Message.message(USER_NUMBER, protocol.composeMessage("prog",hangman.getProgress()));
    }

    private void sendGuess(String guess) {
        String msg = hangman.obtainGuess(guess.charAt(0)); //Gives completed string with letter
        TextView err = (TextView) findViewById(R.id.textView8);
        err.setText(Integer.toString(hangman.getErrors()));
        //Send 1 message
        Log.d("guess","The guess is " + msg);
        Message.message(USER_NUMBER, protocol.composeMessage("prog",msg));
        if (hangman.getErrors() == 10)
            gameOver(-1);
        else if (!msg.contains("_")) {
            gameOver(0);
        }
    }

    private void gameOver(int errors) {
        if (errors == -1) {
            outcome.setText("The user lost the game!");
            outcome.setTextColor(Color.parseColor("#790002"));
            outcome.setVisibility(View.VISIBLE);
        }
        else {
            outcome.setVisibility(View.VISIBLE);
        }
    }

    private void requestHint() {
        Message.message(USER_NUMBER, protocol.composeMessage("hint",hangman.getHint()));
    }

    public void actOnMessage(String body) {
        Log.d("admin","acting on body");
        String validate = protocol.validateMessage(body); //Gives type of message
        Log.d("admin","message type: " + validate);
        String msg = protocol.getMessageBody(body);
        if (validate.equals("help")) {
            requestHint();
        }
        else if (validate.equals("give")) {
            submitCategoriesList();
        }
        else if (validate.equals("cate")) { //Need a better condition, check against database columns
            sendCategory(msg);
        }
        //Guess is sent
        else if (validate.equals("gues")) {
            sendGuess(msg);
        }
    }

    private void submitCategoriesList() {
        String categories = "";
        for (int i = 0; i < db.getCategories().length; i++) {
            categories += db.getCategories()[i] + " ";
        }
        Log.d("admin", "the categories are " + categories);
        Message.message(USER_NUMBER, protocol.composeMessage("list", categories));
    }
}
