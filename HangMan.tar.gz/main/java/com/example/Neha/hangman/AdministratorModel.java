package com.example.Neha.hangman;

public class AdministratorModel {
    private String word;
    private char lastGuess; //Last letter guessed
    private String progress;
    private int errors; //How many guesses were wrong
    private boolean gameOver;
    private String hint;

    public AdministratorModel(String word) { //From a category, picks a word
        this.word = word;
        init();
    }

    private void init() {
        errors = 0;
        progress = "";
        for (int i = 0; i < word.length(); i++) {
            if (word.charAt(i) == ' ')
                progress += " ";
            else
                progress += "_";
        }
        gameOver = false;
    }

    public String obtainGuess(char letter) { //Returns progress
        letter = Character.toUpperCase(letter);
        lastGuess = letter;
        return checkLetterInWord();
    }

    private String checkLetterInWord() { //Returns progress
        System.out.println("You have the word " + progress + " and you guessed the letter " + lastGuess);
        if (progress.indexOf(lastGuess) != -1) {
            System.out.println("This letter is already in your word.");
            errors++; //Depending on rules
            if (errors == 10) {
                System.out.println("You lost");
                gameOver = true;
            }
            return progress;
        }
        else if (word.indexOf(lastGuess) == -1) {
            System.out.println("Sorry, this guess is incorrect.");
            errors++;
            if (errors == 10) {
                System.out.println("You lost");
                gameOver = true;
            }
            return progress;
        }
        else {
            String temp = "";
            for (int i = 0; i < word.length(); i++) {
                if (word.charAt(i) == lastGuess)
                    temp += lastGuess;
                else
                    temp += progress.charAt(i);
            }
            progress = temp;
            System.out.println("Now your word is: " + progress);
            if (progress.indexOf('_') == -1) {
                System.out.println("Nice! You won.");
                gameOver = true;
            }
            return progress;
        }
    }

    public boolean gameOver() {
        return gameOver;
    }

    public String getProgress() {
        return progress;
    }

    //This should be set to true when a new guess is added, to false after it has been evaluated.
    //For the main game cycle
    public int getErrors() {
        return errors;
    }

    public void setHint(String hint) {
        this.hint = hint;
    }

    public String getHint() {
        return hint;
    }
}
