// package goes here
package com.example.Neha.hangman;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_PATH = "/data/data/com.example.alice.hangman/databases/";
    private static final String DB_NAME = "Words.db";

    private final Context myContext;

    public SQLiteDatabase db;

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, 1);
        this.myContext = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void createDatabase() {
        createDB();
    }


    private void openDatabase() throws SQLException {
        //Open the database
        db = SQLiteDatabase.openDatabase(DB_PATH + DB_NAME, null, SQLiteDatabase.NO_LOCALIZED_COLLATORS);
    }

    public String[] getCategories() {
        openDatabase();
        if (db == null)
            Log.wtf("database","something's wrong.");
        Cursor result = db.rawQuery("SELECT DISTINCT Category FROM Words", new String[]{});
        String[] res = new String[result.getCount()];
        result.moveToFirst();
        for (int i = 0; i < result.getCount(); i++) {
            res[i] = result.getString(result.getColumnIndex("CATEGORY"));
            result.move(1);
        }
        return res;
    }

    public String getRandomWord(String category) {
        openDatabase();
        if (db == null)
            Log.wtf("database","something's wrong.");
        Cursor result = db.rawQuery("SELECT Words FROM Words WHERE Category = ? ORDER BY RANDOM() LIMIT 1", new String[]{category});
        //closeDatabase();
        String res = null;
        if(result != null && result.moveToFirst()){
            res = result.getString(result.getColumnIndex("WORDS"));
        }
        return res;
    }

    public String getHint(String word) {
        openDatabase();
        if (db == null)
            Log.wtf("database","something's wrong.");
        Log.wtf("database","getting a hint for word: " + word);
        Cursor result = db.rawQuery("SELECT Hints FROM Words WHERE Words = ?", new String[]{word});
        String res = null;
        if( result != null && result.moveToFirst() ){
            res = result.getString(result.getColumnIndex("HINTS"));
        }
        return res;
    }

    public void addWord(String category, String word, String hint) {
        openDatabase();
        db.execSQL("INSERT INTO Words VALUES (?, ?, ?)", new String[] {category, word, hint});
    }

    private void createDB() {
        boolean dbExists = DBExists();

        if(!dbExists) {
            this.getReadableDatabase(); //Creates an empty file in the correct location
            copyDBFromResource();
        }
    }

    private boolean DBExists() {
        SQLiteDatabase db = null; //Tries to read it from file and put it in variable db

        try {
            String databasePath = DB_PATH + DB_NAME;
            db = SQLiteDatabase.openDatabase(databasePath, null, SQLiteDatabase.OPEN_READWRITE);
            db.setLocale(Locale.getDefault());
            db.setLockingEnabled(true);
            db.setVersion(1);
        } catch (SQLiteException e) {
            Log.e("SqlHelper", "database not found");
        }
        if (db != null) {
            db.close();
            Log.wtf("database","this database is already in data/data folder");
            return true;
        }
        else {
            Log.wtf("database","database not yet copied");
            return false;
        }

    }

    private void copyDBFromResource() {
        InputStream inputStream = null;
        OutputStream outStream = null;
        String dbFilePath = DB_PATH + DB_NAME;

        try {
            inputStream = myContext.getAssets().open(DB_NAME); //The prepopulated database
            outStream = new FileOutputStream(dbFilePath); //The empty database

            byte[] buffer = new byte[1024]; //Copy the file byte by byte
            int length;
            while ((length = inputStream.read(buffer)) > 0) {
                outStream.write(buffer, 0, length);
            }

            outStream.flush();
            outStream.close();
            inputStream.close();

        } catch (IOException e) {
            throw new Error("Problem copying database from resource file.");
        }
    }


}
