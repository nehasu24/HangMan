package com.example.Neha.hangman;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class FrequentContacts extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_frequent_contacts);

        final Spinner spinner = (Spinner) findViewById(R.id.spinner3);
        Button button = (Button) findViewById(R.id.button9);

        PreferencesHelper db = new PreferencesHelper(this);
        String[] numbers = db.getContacts();

        ArrayAdapter<CharSequence> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new ArrayList<CharSequence>());
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        if (numbers.length == 0) {
            TextView message = (TextView) findViewById(R.id.textView21);
            message.setText("You have no saved numbers yet. How about you find someone " +
                    "new to play with? :)");
            spinner.setVisibility(View.INVISIBLE);
            button.setText("Go back");
        }
        else {
            for (String s : numbers) {
                if (s == null)
                    break;
                adapter.add(s);
            }
        }

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String choice = "";
                if (spinner.getVisibility() == View.VISIBLE) {
                    choice = spinner.getSelectedItem().toString();
                }
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                i.putExtra("SELECTED_NUMBER", choice);
                setResult(RESULT_OK,i);
                finish();
            }
        });
    }
}
