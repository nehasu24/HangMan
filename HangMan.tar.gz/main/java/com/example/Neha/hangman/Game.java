package com.example.Neha.hangman;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Game extends AppCompatActivity {

    private static Game inst;
    private UserModel hangman;
    private EditText letter;
    private SmsProtocol protocol;
    private TextView outcome;

    public static Game instance() {
        return inst;
    }

    protected void onPause() { //If we switch between user and game screen
        super.onPause();
        inst = null;
    }

    protected void onResume() {
        super.onResume();
        inst = this;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        inst = this;
        setContentView(R.layout.activity_game);
        protocol = new SmsProtocol();
        outcome = (TextView) findViewById(R.id.textView20);
        outcome.setVisibility(View.INVISIBLE);

        Button check = (Button) findViewById(R.id.button4);
        letter = (EditText) findViewById(R.id.editText);
        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (letter.getText().toString().equals(""))
                    Toast.makeText(inst, "You didn't write any letter!", Toast.LENGTH_SHORT).show();
                else if (letter.getText().toString().length() > 1)
                    Toast.makeText(inst, "This is too long!", Toast.LENGTH_SHORT ).show();
                else if (!Character.isLetter(letter.getText().toString().charAt(0)))
                    Toast.makeText(inst, "Not a letter!", Toast.LENGTH_SHORT ).show();
                else {
                    hangman.getGuess(letter.getText().toString().charAt(0));
                    Message.message(User.getADMIN_NUMBER(),
                            protocol.composeMessage("gues",letter.getText().toString()));
                }
                letter.setText("");
            }
        });

        Button hint = (Button) findViewById(R.id.button5);
        hint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(inst, "Asking for hint...", Toast.LENGTH_SHORT).show();
                Message.message(User.getADMIN_NUMBER(),
                        protocol.composeMessage("help","")); //Message 0 to obtain hint
            }
        });
    }

    private boolean gameStart = true;

    private void updateProgress(String progress) {
        if (hangman == null) { //First run
            hangman = new UserModel();
        }
        TextView text = (TextView) findViewById(R.id.textView11);
        text.setText(progress);
        boolean ok = hangman.updateProgress(progress);
        if (!ok) { //And if the game did not just begin
            Toast.makeText(this, "Wrong guess!", Toast.LENGTH_SHORT).show();
        }
        else if (ok && !gameStart) {
            Toast.makeText(this, "Right guess!", Toast.LENGTH_SHORT).show();
        }
        gameStart = false;
        TextView errors = (TextView) findViewById(R.id.textView13);
        Log.d("errors","according to game: " + hangman.getErrors());
        errors.setText(Integer.toString(hangman.getErrors()));
        if (hangman.getErrors() == 10)
            gameOver(-1);
    }

    public void actOnMessage(String body) {
        String validate = protocol.validateMessage(body); //Gives type of message
        String msg = protocol.getMessageBody(body);
        Log.d("game","prefix is: "+validate);
        //Progress is received
        if (validate.equals("prog") && msg.contains("_")) {
            updateProgress(msg);
        }
        else if (validate.equals("prog") && !msg.contains("_")) {
            //Game over, player wins
            updateProgress(msg);
            gameOver(0);
        }
        //Hint is received
        else if (validate.equals("hint")) {
            Log.d("game", "hinttext: "+ msg);
            Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
        }
    }

    private void gameOver(int errors) { //Change this
        if (errors == 0) {
            outcome.setVisibility(View.VISIBLE);
        }
        else {
            outcome.setText("You lost the game!");
            outcome.setTextColor(Color.parseColor("#790002"));
            outcome.setVisibility(View.VISIBLE);
        }
    }
}
