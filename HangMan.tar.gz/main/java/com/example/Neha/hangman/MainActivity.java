package com.example.Neha.hangman;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button adminBtn;
    private Button userBtn;
    private Button dataBtn;
    private Button contactBtn;
    private Button lastBtn;
    private Uri uriContact;
    private String contactID;     // contacts unique ID
    private static final int SELECT_CONTACT = 42;
    private static final int SELECT_FREQUENT_CONTACT = 23;
    private static final String TAG = MainActivity.class.getSimpleName();
    private String contactNumber;
    private static DatabaseHelper db;
    private static PreferencesHelper prefdb;
    TextView contact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        adminBtn = (Button)findViewById(R.id.button);
        userBtn = (Button)findViewById(R.id.button2);
        dataBtn = (Button)findViewById(R.id.button7);
        contactBtn = (Button)findViewById(R.id.button8);
        lastBtn = (Button)findViewById(R.id.button42);
        contact = (TextView) findViewById(R.id.textView18);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS,
                    Manifest.permission.READ_CONTACTS}, 1);
        }
        db = new DatabaseHelper(this);
        db.createDatabase();
        prefdb = new PreferencesHelper(this);
        adminBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { //Start an Administrator activity.
                Intent i = new Intent(getApplicationContext(), Administrator.class);
                if (contactNumber == null)
                    Toast.makeText(getApplicationContext(),"You need to specify a phone number",
                            Toast.LENGTH_LONG).show();
                else {
                    i.putExtra("USER_NUMBER", contactNumber);
                    startActivity(i);
                }
            }
        });
        userBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { //Start an User activity.
                Intent i = new Intent(getApplicationContext(), User.class);
                if (contactNumber == null)
                    Toast.makeText(getApplicationContext(),"You need to specify a phone number", Toast.LENGTH_LONG).show();
                else {
                    i.putExtra("ADMIN_NUMBER", contactNumber);
                    startActivity(i);
                }
            }
        });
        dataBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), AddWords.class);
                startActivity(i);
            }
        });
        contactBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_PICK);
                i.setType(ContactsContract.Contacts.CONTENT_TYPE);
                startActivityForResult(i, SELECT_CONTACT);
            }
        });
        lastBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), FrequentContacts.class);
                startActivityForResult(i, SELECT_FREQUENT_CONTACT);
            }
        });
    }


    //When we receive a phone number in any way, we check where it comes from
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == SELECT_CONTACT && resultCode == RESULT_OK) {
            Log.d(TAG, "Response: " + data.toString());
            uriContact = data.getData();

            retrieveContactNumber();
        }

        else if (requestCode == SELECT_FREQUENT_CONTACT && resultCode == RESULT_OK) {
            if (data.getStringExtra("SELECTED_NUMBER").length() >= 4) {
                Log.d("main activity","we received the number: "+ data.getStringExtra("SELECTED_NUMBER"));
                contactNumber = data.getStringExtra("SELECTED_NUMBER");
                contact.setText(contactNumber);
            }
        }
    }

    private void retrieveContactNumber() {
        Cursor cursorID = getContentResolver().query(uriContact,
                new String[]{ContactsContract.Contacts._ID}, null, null, null);

        if (cursorID.moveToFirst()) {
            contactID = cursorID.getString(cursorID.getColumnIndex(ContactsContract.Contacts._ID));
        }

        cursorID.close();

        Log.d(TAG, "Contact ID: " + contactID);

        //Obtaining the phone number from the data in the cursor
        Cursor cursorPhone = getContentResolver().query
                (ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},

                ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ? AND " +
                        ContactsContract.CommonDataKinds.Phone.TYPE + " = " +
                        ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE,

                new String[]{contactID}, null);

        if (cursorPhone.moveToFirst()) {
            contactNumber = cursorPhone.getString(cursorPhone.getColumnIndex
                    (ContactsContract.CommonDataKinds.Phone.NUMBER));
        }

        cursorPhone.close();

        contact.setText(contactNumber);
    }
}
