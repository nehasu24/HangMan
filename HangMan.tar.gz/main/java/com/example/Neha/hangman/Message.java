package com.example.Neha.hangman;

import android.telephony.SmsManager;

public class Message {

    private Message() {}

    public static void message(String number, String msg) {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(number, null, msg, null, null);
    }

}
