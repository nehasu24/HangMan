package com.example.Neha.hangman;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class PreferencesHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "Preferences.db";
    private static final String CONTACTS_TABLE_NAME = "Contacts";
    private static final String CONTACTS_COLUMN_ID = "id";
    private static final String CONTACTS_COLUMN_PHONE = "phone";

    public PreferencesHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS Contacts " +
                "(id integer primary key autoincrement, phone text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Contacts");
        onCreate(db);
    }

    public void insertContact(String phone) {
        SQLiteDatabase db = this.getWritableDatabase();
        Log.d("admin","inserting contact " + phone);
        db.execSQL("INSERT INTO Contacts (phone) VALUES (?)", new String[] {phone});
    }

    public String[] getContacts() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor result = db.rawQuery("SELECT DISTINCT phone FROM Contacts", new String[]{});
        String[] res = new String[result.getCount()];
        result.moveToFirst();
        for (int i = 0; i < result.getCount(); i++) {
            res[i] = result.getString(result.getColumnIndex("phone"));
            result.move(1);
        }
        return res;
    }
}
