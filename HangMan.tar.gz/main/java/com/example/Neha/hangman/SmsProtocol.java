package com.example.Neha.hangman;

import android.util.Log;

public class SmsProtocol { //Instantiate in Admin & Game class
    //Use prefixes to distinguish messages
    //Part of the MODEL: no android activities!
    //Message syntax "list" "cate" "gues" "prog" "help" "hint", where help does not take any additional message
    private String lastReceived;

    public SmsProtocol() {
        lastReceived = "none";
    }

    public String composeMessage(String type, String msg) { //If "help", msg is empty
        String result = type + " " + msg; //Example
        return result;
    }

    //Checking method: see if SMS is what was expected
    public String validateMessage(String msg) { //Return the type of message or "none" if unexpected
        String prefix = msg.substring(0,4);
        Log.d("protocol","last received: " + lastReceived);
        if (lastReceived.equals("none")) {
            if (prefix.equals("list") || prefix.equals("give") || prefix.equals("prog")) {
                lastReceived = prefix;
                return prefix;
            }
        }
        else if (lastReceived.equals("give")) {
            if (prefix.equals("cate")) {
                lastReceived = prefix;
                return prefix;
            }
        }
        else if (lastReceived.equals("list")) {
            //Do nothing
        }
        else if (lastReceived.equals("cate") || lastReceived.equals("gues") || lastReceived.equals("help")) {
            if (prefix.equals("gues") || prefix.equals("help")) {
                lastReceived = prefix;
                return prefix;
            }
        }
        else if (lastReceived.equals("prog") || lastReceived.equals("hint")) {
            if (prefix.equals("prog") || prefix.equals("hint")) {
                Log.d("protocol", "prefix is "+prefix);
                lastReceived = prefix;
                return prefix;
            }
        }
        return "none";
    }

    public String getMessageBody(String msg) {
        return msg.substring(5);
    }
}
