package com.example.Neha.hangman;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.telephony.SmsMessage;
import android.util.Log;

public class SmsReceiver extends BroadcastReceiver {
    public static final String SMS_EXTRA_NAME = "pdus";
    private AppCompatActivity inst;

    public void onReceive(Context context, Intent intent) {
        // Get the SMS map from Intent
        Bundle extras = intent.getExtras();

        if (extras != null) {
            // Get received SMS array
            Object[] smsExtra = (Object[]) extras.get(SMS_EXTRA_NAME);

            String body;
            Log.d("sms","the body of the message. " + smsExtra.length);

            SmsMessage sms = SmsMessage.createFromPdu((byte[])smsExtra[0]);

            body = sms.getMessageBody().toString();
            Log.d("sms","message received: " + body);

            //Determine that the current activity should handle the message
            if (null != Administrator.instance()) {
                inst = Administrator.instance();
                ((Administrator)inst).actOnMessage(body);
            }
            else if (null != User.instance()) {
                inst = User.instance();
                ((User)inst).actOnMessage(body);
            }
            else if (null != Game.instance()) {
                inst = Game.instance();
                ((Game)inst).actOnMessage(body);
            }
        }
    }
}
