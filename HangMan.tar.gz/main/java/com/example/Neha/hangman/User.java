package com.example.Neha.hangman;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.StringTokenizer;

public class User extends AppCompatActivity {

    private static String ADMIN_NUMBER; //Number of the User
    private static User inst;
    private static DatabaseHelper db = null;
    private SmsProtocol protocol;
    private PreferencesHelper prefdb;

    public static User instance() {
        return inst;
    }

    protected void onPause() { //If we switch between user and game screen
        super.onPause();
        inst = null;
    }

    protected void onResume() {
        super.onResume();
        inst = this;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        inst = this; //Is this line necessary?
        setContentView(R.layout.activity_user);
        protocol = new SmsProtocol();

        db = new DatabaseHelper(this);
        db.createDatabase();
        prefdb = new PreferencesHelper(this);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            ADMIN_NUMBER = extras.getString("ADMIN_NUMBER");
        }

        //Ask for list of categories: necessary if admin has added a category to their database
        Message.message(ADMIN_NUMBER, protocol.composeMessage("give", ""));
        Log.d("user","message is sent");
    }

    public static String getADMIN_NUMBER() {
        return ADMIN_NUMBER;
    }


    public void actOnMessage(String body) { //What on earth is this???
        //Nothing yet
        String validate = protocol.validateMessage(body); //Gives type of message
        String msg = protocol.getMessageBody(body);

        if (validate.equals("list")) { //Use a string tokenizer to recompose the array of categories
            String[] categories = new String[20];
            StringTokenizer st = new StringTokenizer(msg);
            int i = 0;
            while (st.hasMoreElements()) {
                categories[i++] = st.nextToken();
            }
            prepareSpinner(categories); //Also add the action listener to the button. Maybe change its color. Or change the action idk
        }
    }

    private void prepareSpinner(String[] categories) {
        final Spinner spinner = (Spinner) findViewById(R.id.spinner);

        if (spinner == null)
            Log.d("user","spinner is null");
        ArrayAdapter<CharSequence> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new ArrayList<CharSequence>());
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        Log.d("user","hello");
        for (String s : categories) {
            if (s == null)
                break;
            adapter.add(s);
        }
        Log.d("user","hello2");

        for (int i = 0; i < categories.length; i++) {
            Log.d("user","category " + i + " is: " + categories[i]);
        }


        //Listener for the button
        Button start = (Button) findViewById(R.id.button3);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //We send a SMS to the Administrator then start a new class
                String category = spinner.getSelectedItem().toString();
                Message.message(ADMIN_NUMBER, protocol.composeMessage("cate", category));
                Log.d("user","Message sent to admin");
                prefdb.insertContact(ADMIN_NUMBER);
                Intent i = new Intent(getApplicationContext(), Game.class);
                startActivity(i);
            }
        });
    }
}
