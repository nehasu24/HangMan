package com.example.Neha.hangman;

import android.util.Log;

/**
 * Created by Alice on 01/05/2016.
 */
public class UserModel {
    private char lastGuess; //Created here
    private String progress; //Can not be calculated, must be sent by admin
    private int errors; //Can calculate this
    private boolean gameOver;

    public UserModel() {
        progress = "";
        errors = 0;
        gameOver = false;
    }

    /**
     * It is enough to send the modified word
     * @param newWord
     */

    //What we receive from the server
    public boolean updateProgress(String newWord) {
        //Receive a message
        if (!progress.equals(newWord)) {
            progress = newWord;
            return true;
        }
        else {
            updateErrors();
            return false;
        }
    }

    private void updateErrors() {
        //In response to a message
        errors++;
        if (errors == 10)
            gameOver = true; //You lost
    }

    public int getErrors() {
        Log.d("errors","according to getErrors: " + errors);
        return errors;
    }

    //What we send to the server
    public void getGuess(char letter) {
        lastGuess = letter;
    }

    public boolean gameOver() {
        return gameOver;
    }


}
